<?php 
$db=new mysqli('localhost','1150792','XVj2zhA77B98v3T','1150792')or die('error');
?>
<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		
        <title>Khdamti</title>
        <link rel="shortcut icon" href="assets/img/favicon.png" />
         <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
		  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <!-- All Plugins Css -->
        <link href="assets/css/plugins.css" rel="stylesheet">
	

        <!-- Custom CSS -->
        
           <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/3.5.95/css/materialdesignicons.css" crossorigin="anonymous">
           <link href="assets/css/styles.css" rel="stylesheet">
           <link href="assets/css/plugins.css" rel="stylesheet">
          
    </head>
<style>
.form-control {
    height:56px;
    border-radius: 0;
    font-size: 15px;
    box-shadow: none;
    border:1px solid #e0ecf5;
}

select.form-control:not([size]):not([multiple]) {
    height: 56px;
}
select.form-control.fc-lg:not([size]):not([multiple]) {
    height:62px;
}
.form-control.fc-lg {
    height:62px;
}
textarea.form-control{
	height:180px;
}

.btn-primary {
    border-radius: 3px;
    font-family: ubuntu, -apple-system, BlinkMacSystemFont, segoe ui, Roboto, helvetica neue, Arial, sans-serif;
    font-weight: 700;
    letter-spacing: .05em;
    text-transform: uppercase;
    transition: .33s
}

.btn-primary,
.btn-primary:active,
.btn-primary:focus {
    color: #fff;
    background: #1087eb;
    border-color: #1087eb
}
.btn {
	color: #ffffff;
	padding: 12px 25px;
	cursor: pointer;
	-webkit-box-shadow: 0 1px 6px rgba(0, 0, 0, 0.1);
	box-shadow: 0 1px 6px rgba(0, 0, 0, 0.1);
	-webkit-transition: 0s;
	-o-transition: 0s;
	transition: 0s;
	border-radius:0.1rem;
}
  
    </style>




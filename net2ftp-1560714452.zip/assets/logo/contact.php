<!DOCTYPE html>
<html lang="en">
	
<?php include'header.php';
	include'connexion.php';
	if(isset($_POST['ok']))
		if(!empty($_POST['nome']) || !empty($_POST['email']) || !empty($_POST['subj']) || !empty($_POST['comnt'])){
			$nom=mysqli_real_escape_string($db,$_POST['nom']);
			$email=$_POST['email'];
			$subj=mysqli_real_escape_string($db,$_POST['subj']);
			$comnt=mysqli_real_escape_string($bd,$_POST['cmnt']);
			$req=mysqli_query($bd,"INSERT INTO contact values('','$nom','$email','$subj','$comnt')");
		}
if(!$req){
	swal("Ops Message Not sent", "OK!", "error");
}
else
{
swal({
  title: "Message Sent",
  text: "Your Message has been sent",
  icon: "success",
  button: "Ok!",
});
}
	

 ?>
    <body>
        <div id="main-wrapper">
			<?php include 'nav.php'  ?>
			<div class="clearfix"></div>
			<div class="page-title pt-img-bg" style="background:url(assets/img/ser-1.jpg) no-repeat;">
				<div class="container">
					<div class="col-lg-12 col-md-12">
						<div class="pt-caption text-center mt-5">
							<h1>Get in Touch</h1>
							<p><a href="index.html">Home</a><span class="current-page">Contact Us</span></p>
						</div>
					</div>
				</div>
			</div>
			<div class="clearfix"></div>
			<!-- ============================ Hero Banner End ================================== -->
			
			<!-- ============================ Who We Are Start ================================== -->
			<section>
				<div class="container">
					
					<div class="row">
						
						<div class="col-lg-5 col-md-5 bg-primary">
							<div class="contact-address light-text">
								<div class="add-box">
									<div class="add-icon-box">
										<i class="ti-home"></i>
									</div>
									<div class="add-text-box">
										<h4>Virasat Limited</h4>
										CEO: Sagar Singh<br>
										CFO: Shaurya Singh<br>
									</div>
								</div>
								
								<div class="add-box">
									<div class="add-icon-box">
										<i class="ti-map-alt"></i>
									</div>
									<div class="add-text-box">
										<h4>Head Offices</h4>
										810 Clis Road,<br>
										Indraprash NW11 0PU, India
									</div>
								</div>
								
								<div class="add-box">
									<div class="add-icon-box">
										<i class="ti-email"></i>
									</div>
									<div class="add-text-box">
										<h4>Emails</h4>
										virasat@gmail.com<br>
										my.virasat@gmail.com<br>
									</div>
								</div>
								<div class="add-box">
									<div class="add-icon-box">
										<i class="ti-headphone"></i>
									</div>
									<div class="add-text-box">
										<h4>Calls</h4>
										91+ 123 456 9857<br>
										91+ 258 548 5426<br>
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-7 col-md-7">
							<div class="contact-form">
								<form method="post">
									<div class="form-row">
										<div class="form-group col-md-6">
										  <label>Name</label>
										  <input type="text" class="form-control" placeholder="Name" name="nom" required="">
										</div>
										<div class="form-group col-md-6">
										  <label>Email</label>
										  <input type="email" class="form-control" placeholder="Email" name="email" required="">
										</div>
									</div>
									<div class="form-group">
										<label>Subject</label>
										<input type="text" class="form-control" placeholder="Subject" name="subj" required="">
									</div>
									<div class="form-group">
										<label>Message</label>
										<textarea class="form-control" placeholder="Type Here..." name="comnt" required=""></textarea>
									</div>
									<button type="submit" class="btn btn-primary" name="ok">Send Request</button>
								</form>
							</div>
						</div>
						
					</div>
					
				</div>
			</section>
			<div class="clearfix"></div>
			<!-- ============================ Who We Are End ================================== -->

			<!-- ============================ footer ================================== -->
			
                             <?php include'footer.php'; ?>
			<!-- ============================ footer ================================== -->
			
			

			

		</div>
		<!-- ============================================================== -->
		<!-- End Wrapper -->
		<!-- ============================================================== -->
		
		
		<!-- ============================================================== -->
		<!-- All Jquery -->
		<!-- ============================================================== -->
		<script src="assets/js/jquery.min.js"></script>
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		<script src="assets/js/aos.js"></script>
		<script src="assets/js/perfect-scrollbar.jquery.min.js"></script>
		<script src="assets/js/owl.carousel.min.js"></script>
		<script src="assets/js/jquery-rating.js"></script>
		<script src="assets/js/slick.js"></script>
		<script src="assets/js/slider-bg.js"></script>
		<script src="assets/js/lightbox.js"></script> 
		<script src="assets/js/imagesloaded.js"></script>
		<script src="assets/js/isotope.min.js"></script>
		<script src="assets/js/custom.js"></script>
		<!-- ============================================================== -->
		<!-- This page plugins -->
		<!-- ============================================================== -->

	</body>

<!-- Mirrored from codeminifier.com/virasat-multipurpose-template/virasat/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 11 Mar 2019 19:56:29 GMT -->
</html>
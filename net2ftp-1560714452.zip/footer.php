			
			<!-- ============================ Footer Start ================================== -->
			<footer class="image-bg light-footer" style="background-color: #0f86eb;">
				<div>
					<div class="container">
						<div class="row">
							
							<div class="col-lg-4 col-md-4">
								<div class="footer-widget">
									<aside id="media_image-2" class="widget widget_media_image">
										<a href="index.php">
											<img src="assets/img/logo_footer.png"  class="img-fluid mx-auto" alt="">
										</a>
									</aside>
									<aside id="text-2" class="mt-1 widget widget_text">
										<div class="textwidget"><p class="mg-bottom-0 disable-color">© 2019  Designd by abdelsam and abdelhamid</a><br> All Rights Reserved</p>
										</div>
									</aside>
								</div>
							</div>
							
							<div class="col-lg-8 col-md-8">
								<div class="row">
									
									<div class="col-lg-4 col-md-4">
										<div class="footer-widget">
											<h4 class="widget-title">For Candidats</h4>
											<ul class="footer-menu" >
												<li><a href="candidate.php" style="color: white;" >Submit CV</a></li>
												<li><a href="about.php" style="color: white;" >About Us</a></li>
												<li><a href="contact.php" style="color: white;" >Contact Nous</a></li>
												<li><a href="blog.php" style="color: white;" >Blog</a></li>
												
											</ul>
										</div>
									</div>
									
									<div class="col-lg-4 col-md-4">
										<div class="footer-widget">
											<h4 class="widget-title">For Employes</h4>
											<ul class="footer-menu">
												<li><a href="Job_Listing.php" style="color: white;" >Job List</a></li>
												<li><a href="candidates.php" style="color: white;" >Candidats List</a></li>
												<li><a href="post_job.php" style="color: white;" >Post a Job</a></li>
												
											</ul>
										</div>
									</div>
									
									<div class="col-lg-4 col-md-4">
										<div class="footer-widget">
											<h4 class="widget-title">Useful links</h4>
											<p>52000 Errachidia  BTS Errachidia<br>
												S, CA 714258</p>
												<p>E-job@mail.ru</p>
												<p>+212 7 62 83 78 25</p>
										</div>
									</div>
							
								</div>
							</div>
							
						</div>
					</div>
				</div>

				<div class="footer-bottom" style="background-color: #0075d1;">
					<div class="container">
						<div class="row">
							
							<div class="col-lg-6 col-md-6">
								<ul class="footer-bottom-social">
						<li><a href="#" style="color: white;" ><i class="fa fa-facebook"></i>Facebook</a></li>
						<li><a href="#" style="color: white;" ><i class="fa fa-google-plus">Google+</i></a></li>
						<li><a href="#" style="color: white;" ><i class="fa fa-twitter"></i>Twiiter</a></li>
						<li><a href="#" style="color: white;" ><i class="fa fa-instagram"></i>Instagra</a></li>
						<li><a href="#" style="color: white;" ><i class="fa fa-linkedin"></i>LinkedIn</a></li>
								</ul>
							</div>
							
						</div>
					</div>
				</div>
			</footer>
            <!-- Start of LiveChat (www.livechatinc.com) code -->
<script type="text/javascript">
  window.__lc = window.__lc || {};
  window.__lc.license = 10949767;
  (function() {
    var lc = document.createElement('script'); lc.type = 'text/javascript'; lc.async = true;
    lc.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'cdn.livechatinc.com/tracking.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(lc, s);
  })();
</script>
<noscript>
<a href="https://www.livechatinc.com/chat-with/10949767/" rel="nofollow">Chat with us</a>,
powered by <a href="https://www.livechatinc.com/?welcome" rel="noopener nofollow" target="_blank">LiveChat</a>
</noscript>
<!-- End of LiveChat code -->

			<!-- ============================ Footer End ================================== -->
			  
			<!-- Modal -->
			
      <div class="modal fade " id="getstarted" tabindex="-1" role="dialog" aria-labelledby="registermodal" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content" id="registermodal">
            <div class="modal-header theme-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Login</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
						</div>
			
						
            <div class="modal-body">
						<form method="post">
              <div class="row">
                <div class="form-group col-md-12 col-sm-12">
                  <input type="email" class="form-control" name="email" placeholder="Your Eamil">
                </div>
                
                <div class="form-group col-md-12 col-sm-12">
                  <input type="password" class="form-control" name="password" placeholder="Your Password">
								</div>
						
                <div class="col-md-12 col-sm-12">
                  <button type="submit" name="login" class="btn btn-primary">Login</button>
                  <a  href="inscription.php"  class="btn btn-primary"><i class="fa fa-user" aria-hidden="true"></i> Sing up</a>
                </div>
              </div>
            </form>
            </div>
          </div>
        </div>
			</div>
		
      <!-- End Modal -->